import React from "react";
import "../styles/card.css";

const CategoryCard = ({ title, description, image }) => {
  return (
    <div className="category-card">
      <img src={image} alt={title} className="category-image" />
      <div className="category-info">
        <h3>{title}</h3>
        <p>{description}</p>
      </div>
      <a href="#" className="category-link">→</a>
    </div>
  );
};

export default CategoryCard;
