import React from "react";
import "../styles/hero.css";
//import capsule from "../assets/capsule.png";

const Hero = () => {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>
          <span className="blue-text">Speed up your work</span> <br /> with AI Capsules!
        </h1>
        <p>
          Выберите сферу и процесс, который хотите автоматизировать, и получите AI-Капсулу с готовым решением.
        </p>
        <button className="select-btn">Подобрать AI капсулу</button>
      </div>
      <div className="hero-image">
        <img src={capsule} alt="AI Capsule" />
      </div>
    </section>
  );
};

export default Hero;
